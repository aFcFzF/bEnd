/**
 * @file prod.env.js
 * @author bEnd
 */

'use strict';
module.exports = {
    NODE_ENV: '"production"'
};
