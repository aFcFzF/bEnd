# bEnd

> Build Setup

``` bash

# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# 发布到开发机
npm run deploy 开发机名
map在config/proxy.js下配置
server端配置 https://github.com/fex-team/receiver 或 receiver.php


# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
