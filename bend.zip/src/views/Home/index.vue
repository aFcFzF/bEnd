<template>
    <div class="home pagebox">HOME</div>
</template>

<script>
/**
 * @file 首页
 * @author bEnd
*/
export default {
    name: 'Home'
};

</script>

<style scoped lang="stylus">
.home
   font-size 28px
</style>
