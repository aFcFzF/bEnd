<template>
    <div class="setting">
        <PageTitle title="setting"></PageTitle>
        <div class="pagebox">bEnd 设置</div>
    </div>
</template>

<script>
/**
 * @file 熊掌号设置页面
 * @author bEnd
*/

export default {
    name: 'Setting'
};
</script>

<style scoped lang="stylus">
.setting
    color #000
    margin 0 auto

    .pagebox
        min-height 450px
</style>
