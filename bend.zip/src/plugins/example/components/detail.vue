<template>
    <div class="detail">
        detail
    </div>
</template>
<script>
/**
 * @file 示例详情页面
 * @author bEnd
*/
export default {
    name: 'detail'
};

</script>
