<template>
    <div class="example">
        <PageTitle title="插件名称"></PageTitle>
        <div class="pagebox plugin">
            <span>bEnd业务插件</span>
            <img src="./bend.png">
        </div>
    </div>
</template>
<script>
/**
 * @file example 内容分析页面入口 迁移自运营平台
 * @author bEnd
 */

export default {
    name: 'name'
    // ...code
};
</script>
<style scoped lang="stylus">
.example
    color #000
    font-size 36px
    
    .plugin
        min-height 450px
        text-align center

        img
            width 100%
</style>