/**
 * @file Store list
 * @author bEnd
 */
'use strict';
import Account from './Account';
import Menu from './Menu';

export default {
    Account,
    Menu
};
