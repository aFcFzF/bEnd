/**
 * @file config.js
 * @author bEnd
 * @desc 插件依赖配置
 */

import example from './plugins/example';
export default {
    example
};
